<?php    

    $respuesta = "{\"nombre\": \"Tony\", \"apellido\":\"Stark\"}";

    sleep(4);
    
    echo $respuesta;

?>